/*
 * Vencord, a modification for Discord's desktop app
 * Copyright (c) 2022 Vendicated and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

import { app } from "electron";
import EventEmitter from "events";
import { copyFileSync, existsSync, readdirSync, renameSync, rmSync, statSync } from "original-fs";
import { basename, dirname, join } from "path";

function isNewer($new: string, old: string) {
    const newParts = $new.slice(4).split(".").map(Number);
    const oldParts = old.slice(4).split(".").map(Number);

    for (let i = 0; i < oldParts.length; i++) {
        if (newParts[i] > oldParts[i]) return true;
        if (newParts[i] < oldParts[i]) return false;
    }
    return false;
}

function patchLatest() {
    if (process.env.DISABLE_UPDATER_AUTO_PATCHING) return;

    try {
        const currentAppPath = dirname(process.execPath);
        const currentVersion = basename(currentAppPath);
        const discordPath = join(currentAppPath, "..");

        const latestVersion = readdirSync(discordPath).reduce((prev, curr) => {
            return (curr.startsWith("app-") && isNewer(curr, prev))
                ? curr
                : prev;
        }, currentVersion as string);

        if (latestVersion === currentVersion) return;

        const oldResources = join(discordPath, currentVersion, "resources");
        const oldVencordAsar = join(oldResources, "app.asar");

        const resources = join(discordPath, latestVersion, "resources");
        const newAppAsar = join(resources, "app.asar");
        const newAppAsarBackup = join(resources, "_app.asar");

        if (!existsSync(oldVencordAsar) || !existsSync(newAppAsar)) return;
        // Loaders are tiny; Discord's real app.asar is megabytes. If the new version already
        // has a loader there's nothing to do.
        if (statSync(newAppAsar).size < 64 * 1024) return;

        console.info(`[Larpcord] Detected Host Update (${currentVersion} -> ${latestVersion}). Repatching...`);

        // A leftover _app.asar means Discord reinstalled itself over an earlier patch; the
        // real app.asar it just wrote is the current one.
        if (existsSync(newAppAsarBackup)) rmSync(newAppAsarBackup);
        renameSync(newAppAsar, newAppAsarBackup);
        copyFileSync(oldVencordAsar, newAppAsar);
    } catch (err) {
        console.error("[Larpcord] Failed to repatch latest host update", err);
    }
}

if (process.platform === "win32" || process.platform === "linux") {
    EventEmitter.prototype.emit = new Proxy(EventEmitter.prototype.emit, {
        apply(target, thisArg, argArray) {
            if (argArray[0] === "host-updated") {
                patchLatest();
            }

            return Reflect.apply(target, thisArg, argArray);
        },
    });

    // Try to patch latest on before-quit
    // Discord's Win32 updater will call app.quit() on restart and open new version on will-quit
    app.on("before-quit", patchLatest);
}
